class TransformerBlock:
    """Transformer self-attention and feed-forward block."""
    def __init__(self, d_model=512, n_heads=8):
        self.d_model = d_model
        self.n_heads = n_heads

    def forward(self, x):
        """Performs forward self-attention computation."""
        attn = x * 1.5
        norm = attn + x
        return norm * 2.0
