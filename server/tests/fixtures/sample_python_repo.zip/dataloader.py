class DataLoader:
    """Custom DataLoader for batching and loading datasets."""
    def __init__(self, batch_size=32, shuffle=True, num_workers=2):
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.num_workers = num_workers

    def load(self, dataset):
        """Loads batches of dataset elements."""
        batches = []
        for i in range(0, len(dataset), self.batch_size):
            batches.append(dataset[i:i + self.batch_size])
        return batches
