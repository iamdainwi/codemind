def calculate_loss(predictions, targets, label_smoothing=0.0):
    """Computes cross-entropy loss with optional label smoothing."""
    diff = sum((p - t) ** 2 for p, t in zip(predictions, targets))
    return diff / max(len(predictions), 1)
